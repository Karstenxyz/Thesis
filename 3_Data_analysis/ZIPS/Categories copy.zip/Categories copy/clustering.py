import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

# Load the cleaned data
cleaned_data = pd.read_excel('/Users/karsten/Downloads/Thesis/Results/DATA/Cleaned_Copy_Final_Version3.xlsx')

# Vectorization
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(cleaned_data['cleaned_titles'])

# Dimensionality Reduction (optional)
pca = PCA(n_components=2, random_state=42)
X_reduced = pca.fit_transform(X.toarray())

# Clustering
num_clusters = 20  # Choose an appropriate number of clusters
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
labels = kmeans.fit_predict(X_reduced)

# Evaluation
sil_score = silhouette_score(X_reduced, labels)
print(f'Silhouette Score: {sil_score}')

# Adding cluster labels to the data
cleaned_data['cluster'] = labels

# Plotting the clusters (optional)
plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=labels, cmap='viridis')
plt.title('Proposal Titles Clustering')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.colorbar(label='Cluster')
plt.show()

# Save the updated data with cluster labels to a new Excel file
clustered_file_path = '/Users/karsten/Downloads/Thesis/Results/DATA/Clustered_Copy_Final_Version4.xlsx'
cleaned_data.to_excel(clustered_file_path, index=False)
